"""Where things live. Works the same in Docker (code in /app, data in /data) and when run directly from the project folder."""
import configparser, os
BASE = os.path.dirname(os.path.abspath(__file__))                       # the backend folder
PARENT = os.path.dirname(BASE)
ROOT = PARENT if os.path.isdir(os.path.join(PARENT, "frontend")) else BASE   # project folder, or /app inside the container
DATA = os.getenv("DATA_DIR") or ("/data" if os.path.exists("/.dockerenv") else os.path.join(ROOT, "data"))
FRONT = os.path.join(ROOT, "frontend")

def find(name):  # a config file kept in the project folder (or next to the code)
    return next((p for p in (os.path.join(ROOT, name), os.path.join(BASE, name)) if os.path.exists(p)), os.path.join(ROOT, name))

def db_path():  # NIX_DB env var, else [db] path in db.ini, else data/nix.db
    if os.getenv("NIX_DB"): return os.environ["NIX_DB"]
    cp = configparser.ConfigParser(interpolation=None); cp.read(find("db.ini"))
    p = cp["db"].get("path", "").strip() if cp.has_section("db") else ""
    return p or os.path.join(DATA, "nix.db")
