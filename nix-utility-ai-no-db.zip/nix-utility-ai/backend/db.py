"""Embedded SQLite data layer: one file, nothing to install. The app's SQL is written in a Postgres style and tr() translates the few differences,
so the queries stay readable. Dates, timestamps and JSON columns are converted back to Python objects on the way out."""
import json, os, re, sqlite3, threading
from datetime import date, datetime, timezone
from decimal import Decimal
from paths import db_path

_lock, _con = threading.RLock(), None
JSON_COLS = {"candidates", "classification", "risk", "recommendation"}
DATE_COLS = {"install_date", "last_cleaned_date", "scheduled_for"}
TS_COLS = {"captured_at", "created_at", "updated_at"}
_ISO = re.compile(r"^\d{4}-\d\d-\d\dT\d\d:\d\d")
# "latest observation per asset" is written once with Postgres DISTINCT ON; SQLite gets the equivalent window function
_DISTINCT_ON = re.compile(r"SELECT DISTINCT ON \(o\.asset_id\) (.+?) FROM observations o JOIN assets a ON a\.asset_id=o\.asset_id WHERE (.+?) ORDER BY o\.asset_id,o\.captured_at DESC\)", re.S)

def _latest(m):
    return (f"SELECT {m[1]} FROM (SELECT o.*, ROW_NUMBER() OVER (PARTITION BY o.asset_id ORDER BY o.captured_at DESC) AS rn "
            f"FROM observations o JOIN assets a ON a.asset_id=o.asset_id WHERE {m[2]}) o JOIN assets a ON a.asset_id=o.asset_id WHERE o.rn=1)")

def tr(sql):
    s = _DISTINCT_ON.sub(_latest, sql)
    s = re.sub(r"%\((\w+)\)s", r":\1", s).replace("%s", "?")
    s = re.sub(r"::\w+", "", s)                                   # casts such as ::numeric, ::timestamptz
    s = re.sub(r"\bILIKE\b", "LIKE", s)
    return s.replace("now()-interval '12 months'", "datetime('now','-12 months')").replace("now()", "CURRENT_TIMESTAMP")

def con():
    global _con
    if _con is None:
        p = db_path(); os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
        _con = sqlite3.connect(p, check_same_thread=False, timeout=30, isolation_level=None)   # autocommit
        _con.row_factory = sqlite3.Row; _con.execute("PRAGMA journal_mode=WAL"); _con.execute("PRAGMA synchronous=NORMAL")
    return _con

def norm(v):  # values stored as text: timestamps as UTC "YYYY-MM-DD HH:MM:SS", dates as "YYYY-MM-DD"
    if isinstance(v, datetime): return (v.astimezone(timezone.utc) if v.tzinfo else v).strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, date): return v.isoformat()
    if isinstance(v, Decimal): return float(v)
    if isinstance(v, str) and _ISO.match(v):
        try: return norm(datetime.fromisoformat(v.replace("Z", "+00:00")))
        except ValueError: return v
    return v

def fix(r):
    for k, v in r.items():
        if not isinstance(v, str): continue
        try:
            if k in JSON_COLS: r[k] = json.loads(v)
            elif k in DATE_COLS: r[k] = date.fromisoformat(v[:10])
            elif k in TS_COLS: r[k] = datetime.fromisoformat(v).replace(tzinfo=timezone.utc)
        except ValueError: pass
    return r

def q(sql, a=None, one=False):
    args = {k: norm(v) for k, v in a.items()} if isinstance(a, dict) else tuple(norm(v) for v in a) if a is not None else ()
    with _lock:
        cur = con().execute(tr(sql), args)
        rows = cur.fetchall() if cur.description else None
        cur.close()
    if rows is None: return None
    out = [fix(dict(r)) for r in rows]
    return (out[0] if out else None) if one else out

def script(sql):
    with _lock: con().executescript(sql)

def rollup(rows, keys=("state", "op_area", "city", "station")):  # SQLite has no ROLLUP: add the Station -> City -> OpArea -> State subtotals here
    out = {}
    for r in rows:
        for d in range(len(keys) + 1):
            k = tuple(r[x] for x in keys[:d]) + (None,) * (len(keys) - d)
            o = out.setdefault(k, dict(zip(keys, k), assets_with_issues=0, total_loss_kwh_day=None, total_optimum_kwh_day=None))
            o["assets_with_issues"] += r["assets_with_issues"]
            for f in ("total_loss_kwh_day", "total_optimum_kwh_day"):
                if r[f] is not None: o[f] = (o[f] or 0) + r[f]
    for o in out.values():
        for f in ("total_loss_kwh_day", "total_optimum_kwh_day"):
            if o[f] is not None: o[f] = round(o[f], 1)
    return sorted(out.values(), key=lambda v: tuple((v[x] is not None, v[x] or "") for x in keys))
