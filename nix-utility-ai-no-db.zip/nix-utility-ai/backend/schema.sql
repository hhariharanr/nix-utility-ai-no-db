CREATE TABLE IF NOT EXISTS assets(asset_id TEXT PRIMARY KEY, geojson TEXT, xmin REAL, xmax REAL, ymin REAL, ymax REAL, station TEXT, city TEXT, op_area TEXT, state TEXT, install_date TEXT, capacity_kw REAL, last_cleaned_date TEXT);
CREATE INDEX IF NOT EXISTS assets_bbox ON assets(xmin, xmax, ymin, ymax);
CREATE TABLE IF NOT EXISTS observations(obs_id INTEGER PRIMARY KEY AUTOINCREMENT, asset_id TEXT REFERENCES assets(asset_id), image_path TEXT, captured_at TEXT, source TEXT, issue_class TEXT, severity TEXT, confidence REAL, risk_score INTEGER, risk_level TEXT, energy_loss_kwh_day REAL, asset_confirmed INTEGER DEFAULT 1);
CREATE INDEX IF NOT EXISTS obs_time ON observations(captured_at);
CREATE INDEX IF NOT EXISTS obs_asset ON observations(asset_id);
CREATE TABLE IF NOT EXISTS tickets(ticket_id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT UNIQUE, asset_id TEXT, issue_class TEXT, priority TEXT, action TEXT, notes TEXT, status TEXT DEFAULT 'open', notified_status TEXT, wo_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER, message TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS work_orders(wo_id INTEGER PRIMARY KEY AUTOINCREMENT, station TEXT, scheduled_for TEXT, kind TEXT, status TEXT DEFAULT 'scheduled', source TEXT DEFAULT 'planner');
CREATE TABLE IF NOT EXISTS ingest_items(item_id TEXT PRIMARY KEY, image_path TEXT, captured_at TEXT, lat REAL, lon REAL, method TEXT, candidates TEXT, classification TEXT, reason TEXT, status TEXT, asset_id TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
