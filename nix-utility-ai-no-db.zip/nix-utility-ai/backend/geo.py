"""Small geometry helpers (no spatial library needed): is a point inside a polygon, and how many metres from it."""
import math
M = 111320.0   # metres per degree of latitude

def inside(lon, lat, ring):  # ray casting; ring = [[lon, lat], ...] closed
    c = False
    for (x1, y1), (x2, y2) in zip(ring, ring[1:]):
        if (y1 > lat) != (y2 > lat) and lon < (x2 - x1) * (lat - y1) / (y2 - y1) + x1: c = not c
    return c

def dist_m(lon, lat, ring):  # metres from the point to the polygon outline (flat-earth approximation, fine at panel scale)
    k = M * math.cos(math.radians(lat)); pts = [((x - lon) * k, (y - lat) * M) for x, y in ring]; best = float("inf")
    for (ax, ay), (bx, by) in zip(pts, pts[1:]):
        dx, dy = bx - ax, by - ay; L = dx * dx + dy * dy
        t = 0 if L == 0 else max(0, min(1, -(ax * dx + ay * dy) / L))
        best = min(best, math.hypot(ax + t * dx, ay + t * dy))
    return best
