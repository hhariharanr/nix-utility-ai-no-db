# NiX Utility AI (prototype)

Solar-asset inspection prototype: dashboard map, Chat AI, maintenance planner, photo intake with a human review queue. The database is a single SQLite file (`data/nix.db`), so there is no database server to install.

## Run it (Windows; Mac/Linux equivalents in brackets)
1. Python 3.10-3.12. In the project folder: `python -m venv .venv`, activate it (`.venv\Scripts\activate` [`source .venv/bin/activate`]), then `pip install -r backend\requirements.txt`
2. Set a password in `auth.ini` (the app refuses logins until you change `CHANGE_ME`). Optionally put your model endpoint in `llm.ini`; without it, recommendations use rules and chat gives basic data answers.
3. `python backend\seed.py` creates `data/nix.db` with synthetic demo data (add `--reset` to start over).
4. `run.bat` [`./run.sh`], then open http://localhost:8000 and sign in.

With Docker instead: `docker compose up --build`, then `docker compose exec api python seed.py`.

## Image analysis (EfficientNetB0)
Train on your machine or Colab, then the app picks the model up from `data/`:
```
cd ml && pip install -r requirements.txt
python prepare_data.py --raw raw --out dataset_split --map map.json
python train.py --data dataset_split --out ../data
python evaluate.py --data realworld --model ../data
```
Without `data/model.keras` the app uses a stub classifier. Severity comes from the Grad-CAM coverage (under 25% low, under 55% medium, otherwise high), an assumption to tune. Risk weights, loss table and 5 sun hours are assumptions at the top of `backend/risk.py`.

## Demo photos
- `python backend\geotag.py --in data\demo_photos --out data\demo_geotagged --n 60` gives photos synthetic GPS tags on the seeded panels (use held-out test images); upload them in Photo Intake. `manifest.csv` lists what each should do.
- `python backend\attach_demo_photos.py` gives the synthetic issue records a matching photo (and heat map) from `ml/dataset_split/test`.
The coordinates and records are synthetic; say so in the demo.

## Matching and polygons
`seed.py` draws 3 m x 3 m panels with 5 m gaps (`SEED_SIZE_M`, `SEED_GAP_M`). A photo matches a panel if its GPS point is inside it, or within `MATCH_BUFFER_M` (default 3 m) of exactly one. Consumer GPS is often 3-5 m off, so many real photos will go to the review queue; raise the buffer if that is too strict. After changing geometry, run `seed.py --reset` and re-run `geotag.py`.

## Configuration files
`llm.ini` (model endpoint), `auth.ini` (shared login), `db.ini` (database file location). `llm.ini` and `auth.ini` hold secrets: they are git-ignored, copy the `.example` files after cloning (with Docker a missing file becomes an empty folder and breaks start-up). `data/`, the trained model and datasets are also left out of Git.

## Notes
- The database lives in `data/nix.db`: back it up by copying the file. Several people can use one running app; do not point two machines at the same file over a network drive.
- Photos are files in `data/`, so a team demo should use one shared copy of the app.
