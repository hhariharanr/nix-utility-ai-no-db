#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -x .venv/bin/python ] || { echo "Create the virtual environment first - see the README, section 'Run without Docker'."; exit 1; }
source .venv/bin/activate
# Use --host 0.0.0.0 instead of 127.0.0.1 to let other computers on your network open it (the login still applies).
python -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8000
